<h3> Cotação de moeda BRL - USD </h3>

<div>
    <label for="cota">Converta o valor:</label>
    <input type="text" id="cota" placeholder="Digite aqui o valor em BRL...">
    <button id="converter">Pesquisar</button>
</div>
<div>
    <p>Valor convertido: <span id="converte"></span></p>
    <p>Compra: <span id="compra"></span></p>
    <p>Venda: <span id="venda"></span></p>
    <p>Mínimo: <span id="minimo"></span></p>
    <p>Máximo: <span id="maximo"></span></p>
</div>
<script>
   const cot = document.querySelector("#cota");

    document.querySelector("#converter").addEventListener('click', function(){
        const opcoes = {
            method:'GET',
            mode:'cors',
            cache:'default'
        }

        fetch(`https://economia.awesomeapi.com.br/json/last/USD-BRL`, opcoes).then(
            response => { response.json()
                .then(data => {
                document.querySelector("#converte").textContent = cot.value * data['USDBRL']['bid'];
                document.querySelector("#compra").textContent = data['USDBRL']['bid'];
                document.querySelector("#venda").textContent = data['USDBRL']['ask'];
                document.querySelector("#minimo").textContent = data['USDBRL']['low'];
                document.querySelector("#maximo").textContent = data['USDBRL']['high'];
            });
        })
    });
</script>