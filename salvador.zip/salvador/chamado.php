<?php

/**
 * Plugin Name:       salvador
 * Plugin URI:        https://github.com/lorenmeleti/-Plugin-consumindo-API
 * Description:       Cotação de moeda BRL - USD.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Loren Meleti
 * Author URI:        https://github.com/lorenmeleti
 *
 */

function teste(){	
	return file_get_contents(plugins_url().'/salvador/modificacao.php');
}

add_shortcode("salvador","teste");

?>